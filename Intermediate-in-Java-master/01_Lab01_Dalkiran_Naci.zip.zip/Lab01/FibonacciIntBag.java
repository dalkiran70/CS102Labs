import java.util.Arrays;
/**
 * This class demonstrates first 40 fibonacci number
 * @author Muhammed Naci Dalk�ran
 * @version 09.10.2018
 */ 
public class FibonacciIntBag
{
  public static void main( String[] args )
  {
    //Variable
    int firstFibonacciTerm = 0;
    int secondFibonacciTerm = 1;
    
    
    //Creating fibonacciBag for storing first 40 term of fibonacci series
    IntBag fibonacciBag = new IntBag(); 
    fibonacciBag.add(firstFibonacciTerm);
    fibonacciBag.add(secondFibonacciTerm);
    
    
    for(int i = 2; i < 40; i++) {
      fibonacciBag.add( fibonacciBag.get(i - 1) + fibonacciBag.get(i - 2));
    }
    System.out.println(fibonacciBag.toString());
  }
}