import java.util.Arrays;
import java.util.ArrayList;
/**
 * This is a class which include the collection of integer. 
 * This class helps to create integer pack with its method and proporties.
 * @author Muhammed Naci Dalk�ran
 * @version 09.10.2018
 */ 
public class IntBag
{  
  // variable
  private int[] bag;
  private int valid;
  
  /**
   * Constructer
   * It creates the empty array for storing integer.
   */
  public IntBag()
  {
    valid = 0;
    bag = new int[5];
    bag[0] = -1;
  }
  
  /**
   * Adds a value to the end of the collection
   * @param newValue is a element that will add to end of the collection
   **/
  public void add(int newValue){
    if(newValue >= 0){
      if(bag[bag.length - 1 ] == -1)
      {
        
        int reSizeBag[] = bag;
        bag =  new int[bag.length * 2 ];
        for(int i = 0; i < reSizeBag.length; i++){
          bag[i] = reSizeBag[i];
        }
        
        bag[reSizeBag.length - 1] = newValue;
        bag[reSizeBag.length] = -1;
        valid++;
        
      }
      else
      {
        for(int i = 0; i < bag.length; i++){
          if(bag[i] == -1){
            bag[i + 1 ] = bag[i];
            bag[i] = newValue;
            i = bag.length;
          }
        }
        valid++;
      }
      System.out.println("The Number : " + newValue + " was added");
      
    }
    else{
      System.out.println("That's wrong!!!! the number must be positive");
    }
  }
  
  /**
   * The method Adds the value a special index of array
   * @param newValue is an integer which will be added to the collection 'bag'
   * @param location is the special index for newValue which is going to ve added
   **/
  public void specialLocation(int newValue,int location){
    if((bag.length >= (location - 1) ) && (location >= 0) ){
      
      bag[location] = newValue;
      valid++;
    }
    else if((bag.length <= (location - 1) ) && (location >= 0)){
      int reSizeBag[] = new int[2*bag.length];
      System.arraycopy(bag,0,reSizeBag,0,bag.length);
      bag = reSizeBag;
      valid++;
    }
  }
  
  /**
   * The method removes a value from given index
   * @param index is a indicator of which element is removed from array
   **/
  public void remove( int index )
  {
    
    for(int i = 0; i < bag.length; i++){
      if(bag[i] == -1){
        bag[index] = bag[i-1];
        bag[i - 1] = -1;
        bag[i] = 0;
      }
    }
  }
  

  
  
  /**
   * Thme method observes and tests the array for determining the special value in array 
   * @param givenValue is the number which is looked for
   * @return true whether the collection contains this given value, or false
   **/
  public boolean determineValue(int givenValue){
    
    for( int i = 0; i < bag.length - 1 ; i++){
      if (bag[i] == givenValue){
        
        return true;
      }
    }
    return false;
  }
  
  /**
   * This is a getter method
   * @param i is a index of array
   * @return bag[i] is index of array bag.
   **/
  public int get(int i){
    return bag[i];
  }
  /**
   * This is a getter method
   * @return getSize is size of array
   **/
  public int getSize(){
    return valid;
  }
  /**
   * The method demonstrates messages for users
   * @return the string for informing the users
   **/
  public String toString()
  {
    String total = "";
    for(int i = 0; i < bag.length; i++){
      if(bag[i] != -1){
        total += bag[i] + ", " ; 
      }
      else{
        i = bag.length;
      }
    }
    return total;
  }
}

