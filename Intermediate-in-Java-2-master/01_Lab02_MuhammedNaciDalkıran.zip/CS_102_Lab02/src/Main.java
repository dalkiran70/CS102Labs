import java.util.LinkedList;
import java.util.Scanner;
/*
 * This class is a Main class
 * The option is offered fr users.
 * The urls can be added and demonstrated their content.
 * Author :  Muhammed Naci Dalkıran
 * Date :    23.10.2018
 */
public class Main {
    public static void main ( String[] args ){
        Scanner scan = new Scanner( System.in );

        //Proporties
        LinkedList<MySimpleURLReader> collection;
        int option;
        int index;
        String poemURL;
        boolean isTrue;

        //Program Code
         collection = new LinkedList< >( );

        do {
            System.out.println( "(1) Enter the url of poem to add to collection" );
            System.out.println( "(2) List all poems in the collection" );
            System.out.println( "(3) Quit" );
            System.out.println( "Please Enter your choice" );
            option = scan.nextInt( );

            //For option 1
            if( option == 1 ){
                System.out.println( "Please enter url of poem : " );
                poemURL = scan.next( );
                if(poemURL.indexOf("txt",poemURL.length()- 3 ) != -1 ){
                    collection.add( new MySimpleURLReader( poemURL ) );
                }
                else if (poemURL.indexOf("htm",poemURL.length( ) - 4 ) != -1 )
                {
                    collection.add( new SuperHTMLFilterReader( poemURL ) );
                }
            }
            //For option 2
            else if( option == 2 ){
                isTrue = true;
                System.out.println( );
                for ( int i = 0; i < collection.size( ); i++ ){
                    System.out.println( "index is : " + i + " name is : " + collection.get( i ).getName( ) );
                }
                while(isTrue){
                    System.out.println( "Please enter index of poem : " );
                    index = scan.nextInt( );
                    System.out.println(collection.get( index ).getPageContents( ) );
                    if( index != collection.size( ) );
                    {
                        isTrue = false;
                    }
                }
            }
        // If the users want to quite program
        }while( ( option <= 2 ) && option > 0 );

        System.out.println( "Thank you for using" );
        scan.close( );
    }
}
