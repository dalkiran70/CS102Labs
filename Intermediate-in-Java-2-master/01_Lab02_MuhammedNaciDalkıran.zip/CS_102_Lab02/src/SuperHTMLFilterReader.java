import java.util.ArrayList;
/*
 * The class is storing link of urls in a ArrayList.
 *
 * Author :  Muhammed Naci Dalkıran
 * Date :    23.10.2018
 */
public class SuperHTMLFilterReader extends  HTMLFilterReader{

    /*
     * This is a constructor of this.class
     */
    public SuperHTMLFilterReader(String s) {
        super(s);
    }


    /*
     * This method computes differences of unfilteredPageContent and pageContent as number of lines.
     * @return percentage of differences.
     */
    public double percentage(){

        //Properties
        double differences;

        //Program Code
        differences = ( (double) (getUnfilteredPageContents( ).length( ) - getPageContents().length() )/ (double) getPageContents( ).length( ) );
        return ( differences * 100 );
    }

    /*
     * This is a getter method of Links
     * This method stores URL from html code
     * @return links is a ArrayList which is a Array of URL
     */
    public ArrayList<String> getLinks(){

        //Properties
        ArrayList<String> links;
        String content;

        //Program Code
        content = getUnfilteredPageContents();
        links = new ArrayList<>();

        for (int i = 0; i < content.length() - 3; i++ ) {
            if (content.substring(i, i + 4).equals("href")) {
                int index = content.indexOf("\"", i + 6);
                links.add(content.substring( i + 6, index) );
            }
        }
        return links;
    }
}
