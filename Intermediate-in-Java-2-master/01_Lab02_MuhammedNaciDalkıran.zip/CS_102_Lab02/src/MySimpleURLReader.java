/*
 * This class extends SimpleURLReader class.
 * The class has 2 functions, which are getting URL and Name.
 *
 * Author :  Muhammed Naci Dalkıran
 * Date :    23.10.2018
 */
import cs1.SimpleURLReader;

public class MySimpleURLReader extends SimpleURLReader {

    //Proporties
    String url;

   /*
    * This is a constructor of this.class
    */
    public MySimpleURLReader(String s) {
        super(s);
        url = s;
    }

    /*
     * This is getter method of URL
     * @return url is a URL of the site.
     */
    public String getURL(){

        return url;
    }

    /*
     * This is getter method of Name.
     * This method is doing to take a name from URL.
     * @return fileName is a name of file.
     */
    public String getName(){
        //Properties
        String fileName;
        int index;

        //Program Code
        index = url.lastIndexOf('/');
        fileName = url.substring(index + 1);
        return  fileName;
    }

    @Override
    public String getPageContents() {
        return super.getPageContents().substring(4);
    }
}

