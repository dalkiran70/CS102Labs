import cs1.SimpleURLReader;
/*
 *This is a Test Class in order to look at the differences and process.
 *
 * Author :  Muhammed Naci Dalkıran
 * Date :    23.10.2018
 */
public class TestClass {

    public static void main( String[] args ) {
        //Proporties
        String testString1;
        String testString2;
        String testString3;

        //Program Code
        testString1 = "http://www.cs.bilkent.edu.tr/~david/housman.txt";
        testString2 = "http://www.cs.bilkent.edu.tr/~adayanik/courses/cs102/docs/housman.htm";
        testString3 = "https://docs.oracle.com/javase/tutorial/";

        SimpleURLReader test1 = new SimpleURLReader( testString1 );
        System.out.println( test1.getLineCount( ) );
        System.out.println( test1.getPageContents( ) );

        MySimpleURLReader test2 = new MySimpleURLReader( testString1 );
        System.out.println( test2.getLineCount( ) );
        System.out.println( test2.getPageContents( ) );

        HTMLFilterReader test3 = new HTMLFilterReader( testString2 );
        System.out.println( test3.getLineCount( ) );
        System.out.println( test3.getPageContents( ) );
        System.out.println( test3.delete() );

        SuperHTMLFilterReader test4 = new SuperHTMLFilterReader( testString3 );
        System.out.println(test4.getLinks( ) );



    }
}

