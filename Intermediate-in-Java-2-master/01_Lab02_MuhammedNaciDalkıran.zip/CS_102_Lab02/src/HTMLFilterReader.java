/*
 * This class provide costumers with opportunities to filtered content.
 * Actually, it helps to create web-page content without HTML code.
 *
 * Author :  Muhammed Naci Dalkıran
 * Date :    23.10.2018
 */
public class HTMLFilterReader extends MySimpleURLReader {

    /*
     * This is a constructor of this.class
     */
    public HTMLFilterReader( String s )  {
        super( s );
    }

    /*
     * This is a  Override method of getPageContents.
     * This method filters the web-page content from HTML code.
     * @return temp is a filtered content of web-page
     */
    @Override
    public String getPageContents( ) {
        //properties
        String filteredString;
        String temp;
        boolean cutPoint;

        //Program Code
        filteredString  = super.getPageContents( );
        temp = "";
        cutPoint = false;

        for( int i = 0; i < filteredString.length( ) ;  i++ ){
           if ( filteredString.charAt( i ) == '<' ){
               cutPoint = true;

           }
           else if ( filteredString.charAt( i ) == '>' ){
               cutPoint = false;
           }
           else if ( !cutPoint ){
               temp += filteredString.charAt( i );
           }
        }
        return temp;
    }
    /*
     * This is a getter method of unfiltered page content
     * @return super.getPageContents() is a extended  class method.
     */
    public String getUnfilteredPageContents(){
        return super.getPageContents();
    }

    public String delete(){
        //Properties
        String deletedContent;
        boolean cutPoint;
        String temp;

        //Program Code
        cutPoint = false;
        deletedContent = this.getPageContents();
        temp = "";

        for(int i = 0; i <  deletedContent.length( ) ; i++ ){
            if (deletedContent.charAt( i ) == '&') {
                cutPoint = true;
            }
            else if ( deletedContent.charAt( i ) == ';') {
                cutPoint = false;
            }
            else if (!cutPoint) {
                temp += deletedContent.charAt( i );

            }
        }
        deletedContent = temp;
        return deletedContent;
    }
}
