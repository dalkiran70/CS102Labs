/**
 * ShapeTester class is a main class, and it tests working of other class.
 *  @Author : Muhammed Naci Dalkıran
 *  @Version : 6.11.2018
 */
import java.util.Scanner;

public class ShapeTester {
    public static void main( String[] args ){
        Scanner scan = new Scanner( System.in );

        //Constant

        //Variable
        int option;
        int side1;
        int side2;
        int radius;
        int forShape;
        int a;
        int b;
        ShapeContainer shapeContainer;


        //Program Code
        System.out.println( "Welcome to our application" );
        shapeContainer = new ShapeContainer( );
        do {
            //Options
            System.out.println( "Press 1 : Create an empty set of and Add the shape" );
            System.out.println( "Press 2 : Compute & Print out total surface area of the entire set of shapes" );
            System.out.println( "Press 3 : Print out information about all of the shapes" );
            System.out.println( "Press 4 : Find the first Shape that contains a given x, y point") ;
            System.out.println( "Press 5 : Remove all selected item " );
            option = scan.nextInt( );

            if ( option == 1 ){
                System.out.println( "Please enter the type of the shape you want to add\n"
                        + "1 --> Circle\n"
                        + "2 --> Rectangle\n"
                        + "3 --> Square\n"
                        + "-----------------------------------------");

                forShape = scan.nextInt( );
                if ( forShape == 1 ){
                    System.out.println( "Please enter the radius length" );
                    radius = scan.nextInt( );
                    shapeContainer.add( new Circle ( radius ) );
                }
                else if ( forShape == 2 ){
                    System.out.println( "Please enter the lengths of sides" );
                    side1 = scan.nextInt( );
                    side2 = scan.nextInt( );
                    shapeContainer.add( new Rectangle ( side1, side2 ) );
                }
                else if ( forShape == 3 ){
                    System.out.println( "Please enter the length of sides");
                    side1 = scan.nextInt( );
                    shapeContainer.add( new Square( side1 ) );
                }
                else{
                    System.out.println( " !!! Invalid selection !!! " );
                }


            }
            else if( option == 2 ){
                System.out.println( shapeContainer.getArea( ) );

            }
            else if( option == 3 ){
                System.out.println( shapeContainer.toString( ) );
            }
            else if ( option == 4 ) {
                System.out.println( " what is the x-axis ");
                a = scan.nextInt( );
                System.out.println( " What is the y-axis ");
                b = scan.nextInt( );
                shapeContainer.findContains( a , b );
            }
            else if ( option == 5 ){
                shapeContainer.removeSelected( );
            }

        }while( option <= 5 );

        System.out.println( " !!! Thank you For using !!!" );
    }

}
