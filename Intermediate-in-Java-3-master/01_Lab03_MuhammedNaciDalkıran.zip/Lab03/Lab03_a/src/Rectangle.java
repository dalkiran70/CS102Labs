/**
 * This is a Rectangle class.
 * It extends abstract class of Shape and interface of Locatable
 * It creates Rectangle
 *  @Author : Muhammed Naci Dalkıran
 *  @Version : 5.11.2018
 */
public class Rectangle extends Shape implements Selectable {

    //Properties

    private boolean isSelected;
    private int width;
    private int height;


    /**
     * This is a constructor method of Rectangle Class
     *
     * @param width  is a width of Rectangle
     * @param height is a height of rectangle
     */
    public Rectangle(int width, int height) {
        this.height = height;
        this.width = width;
        x = 0;
        y = 0;
        isSelected = false;
    }


    /**
     * This is a getter method of Area
     * This method is actually override by  Abstract Shape class
     *
     * @return with* height is a area of rectangle
     */
    @Override
    double getArea() {
        return width * height;
    }

    /**
     * It is a toString method of rectangle
     * @return the properties of rectangle
     */
    public String toString() {

        return "The width of the rectangle is : " + width +
                " The height of the rectangle is : " + height +
                ". \nSelected : " + getSelected();
    }


    /**
     * It is a getter method of selected item
     *
     * @return isSelected is a boolean variable
     */
    @Override
    public boolean getSelected() {
        return isSelected;
    }

    /**
     * It is a setter method of Selected
     *
     * @param a is a boolean variable
     */
    @Override
    public void setSelected(boolean a) {
        isSelected = a;
    }

    /**
     * This method monitor to contains this shape in this location
     *
     * @param a integer variable which is located x
     * @param b integer variable which is located y
     * @return the boolean value if Shape contains a and b points, true; otherwise false
     */
    @Override
    public Shape contains(int a, int b) {
        //Program Code
        if (Math.abs(x - a) <= width / 2 && Math.abs(y - b) <= height / 2) {
            return this;
        } else
            return null;

    }
}


