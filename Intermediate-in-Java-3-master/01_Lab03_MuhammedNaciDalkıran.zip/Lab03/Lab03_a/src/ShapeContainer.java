/**
 * ShapeContainer class stores the Shapes namely Circle, Rectangle, Square
 *  @Author : Muhammed Naci Dalkıran
 *  @Version : 6.11.2018
 */
import java.util.LinkedList;

public class ShapeContainer {

    //Properties
    private LinkedList<Shape> shapeSet;

    /**
     * This is a constructor method of ShapeContainer Class
     * Create a empty set of Shapes
     */
    public ShapeContainer() {
        shapeSet = new LinkedList<>();
    }

    /**
     * Method adds the Shapes into set.
     * @param s is anyShape adding into set
     */
    public void add(Shape s) {

        shapeSet.add(s);
    }

    /**
     * Method calculates the total area of Shapes
     * @return totalArea
     */
    public double getArea() {

        //variable
        double totalArea;

        //Program Code
        totalArea = 0;
        for (int i = 0; i < shapeSet.size(); i++) {
            totalArea += shapeSet.get(i).getArea();
        }
        return totalArea;
    }

    /**
     * Method is a toString method
     * @return String collects all shapes properties
     */
    public String toString() {
        //Variable
        String total = "";

        //Program code
        for (int i = 0; i < shapeSet.size(); i++) {
            total += shapeSet.get(i).toString() + "\n";
        }
        return total;
    }

    /**
     * This method monitor to contains all shapes in this location
     * firstly, The instance of Shape is determined
     * secondly, The properties of shape, namely boolean value of contains and getSelected method is determined.
     * finally, change the its setSelected boolean value
     * @param a  integer variable which is located x
     * @param b  integer variable which is located y
     */
    public void findContains(int a, int b) {

        for (int i = 0; i < shapeSet.size(); i++) {
            Shape temp = shapeSet.get(i);

            if (temp instanceof  Selectable ) {
                Selectable sel = (Selectable) temp;
                if (sel.contains(a,b) != null)
                        sel.setSelected(true);
            }
        }

    }
    /**
     * This method remove the shapes from their set.
     * firstly, The instance of Shape is determined
     * secondly, The property of shape, namely boolean value of getSelected
     * finally, if this shape is selected, it is removed from set
     */
    public void removeSelected() {

        for (int i = 0; i < shapeSet.size(); i++) {
            Shape temp = shapeSet.get(i);
            if (temp instanceof  Selectable ) {
                Selectable sel = (Selectable) temp;
                if (sel.getSelected()){
                    shapeSet.remove(i);
                }
            }
        }
    }
}