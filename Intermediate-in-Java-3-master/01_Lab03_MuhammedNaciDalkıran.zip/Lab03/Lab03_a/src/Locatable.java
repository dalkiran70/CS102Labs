public interface  Locatable {
    //Methods
    int getX( );
    int getY( );
    void setLocation( int x, int y ) ;
}
