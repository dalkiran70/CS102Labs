/**
 * Square class extends Rectangle
 * The class create Square Shape.
 *  @Author : Muhammed Naci Dalkıran
 *  @Version : 6.11.2018
 */
public class Square extends Rectangle{

    //Properties
    private int side1;

    /**
     * This is a constructor method of Circle Class
     * @param side1 is side of square
     */
    public Square( int side1 ) {
        super( side1,side1 );
        this.side1 = side1;
}

    /**
     * This getter method of Area
     * @return Area from its parent class.
     */
    @Override
    double getArea( ) {
        return super.getArea( );
    }

    /**
     * It is a toString method of square
     * @return the properties of square
     */
    public String toString( ){
        return "The side of square is : " + side1 +
                "\nSelected : " + getSelected( );
    }
}
