/**
 * Selectable interface contains some methods which are setSelected, getSelected,contains.
 *  @Author : Muhammed Naci Dalkıran
 *  @Version : 6.11.2018
 */
public interface Selectable {
    void setSelected(boolean a);
    boolean getSelected();
    Shape contains(int a , int b);
}
