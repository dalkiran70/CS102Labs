
/**
 * This is a abstract class
 * It holds common method of Shapes, which is Area
 *  @Author : Muhammed Naci Dalkıran
 *  @Version : 5.11.2018
 */
public abstract class Shape implements Locatable {
     int x;
     int y;
    //method
    abstract double getArea( ) ;
    /**
     * It is a getter method of x components of
     * @return x is a x-axis component
     */
    @Override
    public int getX( ) {
        return x;
    }

    /**
     * It is a getter method of y components of cartesian
     * @return y is a y-axis component
     */
    @Override
    public int getY( ) {
        return y;
    }

    /**
     * It is a setter method of Location
     * @param x is a x-axis component
     * @param y is a y-axis component
     */
    @Override
    public void setLocation( int x, int y ) {
        this.x = x;
        this.y = y;
    }

}
