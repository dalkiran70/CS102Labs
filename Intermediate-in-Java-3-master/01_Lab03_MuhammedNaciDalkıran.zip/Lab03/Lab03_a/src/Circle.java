/**
 * Circle class extends shape which implements Locatable interface
 * Also, this class creates Circle object
 *  @Author : Muhammed Naci Dalkıran
 *  @Version : 6.11.2018
 */
public class Circle extends Shape implements Selectable{

    //Properties
    private int radius;

    boolean isSelected;

    /**
     * This is a constructor method of Circle Class
     * @param radius is a radius of Circle
     */
    public Circle( int radius ){
        this.radius = radius;
        x = 0;
        y = 0;
        isSelected = false;
    }

    /**
     * This is a getter method of Area
     * @return area of the Circle
     */
    @Override
    double getArea( ) {
        //program Code
        return ( Math.pow( radius , 2 ) * Math.PI );
    }
    /**
     * This is a toString method
     * @return String which gives information about the shape
     */
    public String toString( ){

        return "The radius of circle is : " + radius +
                ". \nSelected : " + getSelected( );
    }

    /**
     * It is a getter method of selected item
     * @return isSelected is a boolean variable
     */
    @Override
    public boolean getSelected( ){
        return isSelected;
    }

    /**
     * It is a setter method of Selected
     * @param a is a boolean variable
     */
    @Override
    public void setSelected( boolean a ){
        isSelected = a;
    }

    /**
     * This method monitor to contains this shape in this location
     * @param a  integer variable which is located x
     * @param b  integer variable which is located y
     * @return the boolean value if Shape contains a and b points, true; otherwise false
     */
    @Override
    public Shape contains ( int a, int b ) {
        //Program Code
        if ( ( Math.pow( ( x - a), 2 ) + Math.pow( ( y - b ), 2) ) <= radius * radius ) {
            return this;
        } else
            return null;
    }
}
