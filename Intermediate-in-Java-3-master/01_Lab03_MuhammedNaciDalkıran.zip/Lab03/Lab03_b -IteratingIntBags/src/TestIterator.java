/**
 * TestIterator class is a main class and it tests how iterator is working.
 *  @Author : Muhammed Naci Dalkıran
 *  @Version : 6.11.2018
 */
import java.util.Iterator;
import java.util.Scanner;

public class TestIterator {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);

        //Variable
        IntBag bag;
        Iterator i, j;

        //Program Code
        bag = new IntBag();

        for ( int k = 0; k < 10; k++){
            bag.add(k);
        }

        for (Integer l : bag)
        {
            System.out.println(l);
        }
        i = new IntBagIterator( bag );

        while ( i.hasNext() )
        {
            System.out.println( i.next() );

            j = new IntBagIterator( bag );
            // j = bag.iterator();

            while ( j.hasNext() )
            {
                System.out.println( "--" + j.next() );
            }
        }


    }
}
