
/**
 * this is interface class extends Iterator.
 * @Author : Muhammed Naci Dalkıran
 * @Version : 06.11.2018
 **/
import java.util.Iterator;

public interface IntIterator extends Iterator<Integer> {

    int nextInt();

}
