import java.util.Arrays;
import java.util.Scanner;
/**
 * This class tests IntBag class.
 * @author Muhammed Naci Dalkiran
 * @version 09.10.2018
 */
public class IntBagTest
{
    //Variables
    private static int givenValue;
    private static IntBag newBag;

    public static void main( String[] args )
    {
        Scanner scan = new Scanner( System.in);

        int option;


        do
        {
            //The options for users
            System.out.println( "Welcome to menu\n");
            System.out.println( "1. Create a new empty collection(any previous values are lost!)");
            System.out.println( "2. Read a set of positive values into the collection (use a zero value to indicate all the values have been entered.");
            System.out.println( "3. Print the collection of values.");
            System.out.println( "4. Add a value to the collection of values at a specified location.");
            System.out.println( "5. Remove the value at a specified location from the collection of values.");
            System.out.println( "6. Remove all instances of a value within the collection");
            System.out.println( "7. Quit the program.");

            System.out.println( "Please select an operation with typing 1-7");
            option = scan.nextInt();

            //Creating new collection
            if( option == 1 )
            {
                newBag = new IntBag();
            }

            //set integer
            else if( option == 2 )
            {
                int values;
                int number;

                //myBag = new IntBag();

                System.out.println( "Enter values and enter negative value to stop." );
                values = scan.nextInt();

                while( values > 0 )
                {
                    newBag.add( values );
                    values = scan.nextInt();
                }

            }

            else if( option == 3 )
            {
                System.out.println( newBag.toString() );
            }

            else if( option == 4 )
            {
                int valueToAdd;
                int i;

                System.out.println( "Enter a value will be added.");
                valueToAdd = scan.nextInt();

                System.out.println( "Enter an index of a value will be added.");
                i = scan.nextInt();
                newBag.specialLocation( valueToAdd, i );
            }

            else if( option == 5 )
            {
                int i;

                System.out.println( "Enter an index of a value will be removed.");
                i = scan.nextInt();
                newBag.remove( i );
            }

            else if( option == 6 )
            {
                System.out.println( "Enter a test value.");
                givenValue = scan.nextInt();

                while (newBag.determineValue(givenValue)){

                    for(int i = 0; i < newBag.getSize(); i++){
                        if(newBag.get(i) == givenValue){
                            newBag.remove(i);
                        }

                    }
                }

            }



        } while ( option != 7 );
        System.out.println( "Have a Good Day :) :)" );
    }
}
