
/**
 * The class implements interface Iterator
 * Therefore; there are method of Iterator.
 * @Author : Muhammed Naci Dalkıran
 * @Version : 06.11.2018
 **/
import java.util.Iterator;

public class IntBagIterator implements Iterator<Integer> {

    //Properties
    IntBag aBag;
    int index;

    /**
     * It is a constructor method of this class
     * @param aBag is a object of IntBag class
     **/
    public IntBagIterator(IntBag aBag){
        this.aBag = aBag;
        index = 0;
    }

    /**
     * The method monitor that there is a element of collection.
     * @return boolean variable if there is a element, true; otherwise false.
     **/
    @Override
    public boolean hasNext() {
        if( index < aBag.valid){
            return true;
        }else
        return false;
    }

    /**
     * The method iterate the next object in the collection.
     * @return temp of object variable which is value of collection.
     **/
    @Override
    public Integer next() {
        Integer temp = aBag.bag[index];
        index ++;
        return temp;
    }


}
